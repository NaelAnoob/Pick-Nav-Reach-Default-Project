"""Contact-force regulation using the supplied position-target action space."""
import numpy as np


class GripRegulator:
    """Keep squeeze below saturation so unequal jaw loads restore centering.

    Both jaws share an aperture correction. Independent integral controllers
    would cancel the force imbalance that keeps the object centered. This
    controller does not change motor force limits or contact properties.
    """
    def __init__(self, finger_positions, force=20.):
        positions = np.asarray(finger_positions, float)
        self.center = float((positions[0]-positions[1])/2)
        self.opening = float(positions.mean()-force/6200.)
        self.force = float(force)

    def targets(self, normal_forces):
        mean_force = float(np.mean(normal_forces))
        self.opening += np.clip(2.5e-5*(mean_force-self.force), -.0003, .0003)
        self.opening = float(np.clip(self.opening, abs(self.center), .05-abs(self.center)))
        return np.clip([self.opening+self.center, self.opening-self.center], 0., .05)


class BalancedGrip:
    """Retain full available squeeze while reserving differential centering."""
    def __init__(self, positions):
        self.center = (positions[0]-positions[1])/2

    def targets(self, positions, forces):
        error = (positions[0]-positions[1])/2-self.center
        desired = np.clip([60+2000*error, 60-2000*error], 40., 60.)
        squeeze = np.clip(desired+.3*(desired-np.asarray(forces)), 30., 60.)
        return np.clip(np.asarray(positions)-squeeze/6200., 0., .05)
