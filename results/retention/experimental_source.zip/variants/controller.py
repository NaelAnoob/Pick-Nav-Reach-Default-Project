"""Reproducible pick-only demo: python controller.py --headless --objects 5."""
import argparse
import csv
import json
from pathlib import Path
import time

import numpy as np
import pybullet as p
from PIL import Image, ImageDraw
from scipy.spatial.transform import Rotation

from grasping import MotionPlanner, generate_grasps, transport_grasps, aligned_grasps, wrench_grasps, surface_grasps, narrow_grasps, facet_grasps
from pick_nav_reach_env import PickNavReachEnv


class HoldController:
    def __init__(self, initial_obs):
        self.target_qpos = initial_obs['qpos'].copy()

    def get_action(self, obs):
        return self.target_qpos.copy()


class GraspExperiment:
    def __init__(self, env, output, record=False, mu=0.5, grasp_mode='topdown', grasp_skip=0,
                 fast_pick=False):
        self.env, self.output, self.record = env, Path(output), record
        self.output.mkdir(parents=True, exist_ok=True)
        self.planner = MotionPlanner(env, env.seed)
        self.mu = mu
        self.grasp_mode = grasp_mode
        self.grasp_skip = grasp_skip
        self.feasible_grasps = 0
        self.fast_pick = fast_pick
        self.tip_tall = False
        self.preparation = None
        self.frames, self.trace = [], []
        self.phase = 'settle'
        self.initial_relative = None
        self.initial_relative_rotation = None
        self.initial_ee_rotation = None
        self.selected = None
        self.candidate_failures = []
        self.start_time = time.perf_counter()
        self.table_height = p.getAABB(env.table_id)[1][2]

    def capture(self):
        view = p.computeViewMatrixFromYawPitchRoll(getattr(self, 'camera_focus', [-.25, 0, .85]), 2.3, 135, -24, 0, 2)
        proj = p.computeProjectionMatrixFOV(48, 1.5, .05, 10)
        rgba = p.getCameraImage(720, 480, view, proj, renderer=p.ER_TINY_RENDERER)[2]
        pixels = np.frombuffer(rgba, dtype=np.uint8) if isinstance(rgba, bytes) else np.asarray(rgba, dtype=np.uint8)
        im = Image.fromarray(pixels.reshape(480, 720, 4)[:, :, :3])
        draw = ImageDraw.Draw(im)
        draw.rectangle((0, 0, 720, 33), fill=(20, 29, 47))
        draw.text((14, 10), f'Pick-Nav-Reach | object {self.env.object_idx} | seed {self.env.seed} | {self.phase}', fill='white')
        return im

    def step(self, q):
        q = np.asarray(q)
        if q.shape != (self.env.action_size,) or not np.isfinite(q).all():
            raise ValueError('Controller must return finite absolute joint targets')
        obs, _ = self.env.step(q)
        contacts = p.getContactPoints(self.env.robot_id, self.env.object_id)
        touching = {c[3] for c in contacts if c[9] > .01}
        bottom = p.getAABB(self.env.object_id)[0][2]
        ee = p.getLinkState(self.env.robot_id, self.planner.ee, computeForwardKinematics=True)
        inv = p.invertTransform(ee[4], ee[5])
        relative_pose = p.multiplyTransforms(*inv, obs['object_pos'], obs['object_xyzw'])
        relative = np.array(relative_pose[0])
        relative_rotation = Rotation.from_quat(relative_pose[1])
        ee_rotation = Rotation.from_quat(ee[5])
        if self.phase == 'hold' and self.initial_relative is None:
            self.initial_relative = relative.copy()
            self.initial_relative_rotation = relative_rotation
            self.initial_ee_rotation = ee_rotation
        drift = np.linalg.norm(relative-self.initial_relative) if self.initial_relative is not None else 0.
        rotation_drift = ((relative_rotation*self.initial_relative_rotation.inv()).magnitude()
                          if self.initial_relative_rotation is not None else 0.)
        fingers = sorted(self.planner.fingers)
        forces = [sum(c[9] for c in contacts if c[3] == finger) for finger in fingers]
        tangential = [sum(np.hypot(c[10], c[12]) for c in contacts if c[3] == finger)
                      for finger in fingers]
        object_mu = p.getDynamicsInfo(self.env.object_id, -1)[1]
        friction = [object_mu*p.getDynamicsInfo(self.env.robot_id, finger)[1] for finger in fingers]
        obstacle_contacts = [c for body in self.planner.obstacles
                             for c in p.getContactPoints(self.env.robot_id, body)]
        self.trace.append(dict(step=self.env.step_count, physics_steps=self.env.step_count*self.env.substeps,
            phase=self.phase, object_z=float(obs['object_pos'][2]), bottom_z=float(bottom),
            clearance=float(bottom-self.table_height), bilateral_contact=self.planner.fingers <= touching,
            relative_drift=float(drift), relative_rotation_rad=float(rotation_drift),
            gripper_rotation_rad=float((ee_rotation*self.initial_ee_rotation.inv()).magnitude()
                if self.initial_ee_rotation is not None else 0.),
            gripper_x_m=float(ee[4][0]), gripper_y_m=float(ee[4][1]), gripper_z_m=float(ee[4][2]),
            relative_x_m=float(relative[0]), relative_y_m=float(relative[1]), relative_z_m=float(relative[2]),
            finger_1_force_n=float(forces[0]), finger_2_force_n=float(forces[1]),
            finger_1_tangent_n=float(tangential[0]), finger_2_tangent_n=float(tangential[1]),
            finger_1_friction=friction[0], finger_2_friction=friction[1],
            finger_1_position_m=float(obs['qpos'][-2]), finger_2_position_m=float(obs['qpos'][-1]),
            base_speed_m_s=float(np.linalg.norm(obs['qvel'][:2])),
            obstacle_penetration_m=max((-c[8] for c in obstacle_contacts), default=0.)))
        if self.record and self.env.step_count % 8 == 0:
            self.frames.append(self.capture())
        return obs

    def move(self, path, phase, increment=.020, smooth=False):
        self.phase = phase
        for goal in path[1:]:
            start = self.env.agent_qpos.astype(float)
            count = max(1, int(np.ceil(np.max(np.abs(goal-start))/increment)))
            for t in range(1, count+1):
                fraction = t/count
                if smooth:
                    fraction = fraction**3*(10-15*fraction+6*fraction*fraction)
                self.step(start+(goal-start)*fraction)
        for _ in range(15):
            self.step(path[-1])

    def query(self, fn):
        saved = p.saveState()
        try:
            return fn()
        finally:
            p.restoreState(saved)
            p.removeState(saved)

    def run(self):
        q = self.env.agent_qpos.astype(float)
        q[-2:] = .05
        for _ in range(60):
            self.step(q)
        ready = q.copy()
        ready[3] = .3
        ready[7], ready[9], ready[11] = -.65, 1.5, .72
        path = self.query(lambda: self.planner.plan(self.env.agent_qpos.astype(float), ready))
        if path is None:
            return self.finish('no collision-free ready posture')
        self.move(path, 'ready', increment=.03 if self.fast_pick else .02)
        near = ready.copy()
        near[0] = 1.25
        path = self.query(lambda: [self.env.agent_qpos.astype(float), near]
                          if self.planner.edge(self.env.agent_qpos, near) else None)
        if path is None:
            return self.finish('base approach blocked')
        self.move(path, 'base approach', increment=.015)
        if self.tip_tall:
            self.prepare_object()
        obs = self.env._get_obs()
        generator = dict(transport=transport_grasps, aligned=aligned_grasps, surface=surface_grasps,
                         narrow=narrow_grasps, facet=facet_grasps).get(self.grasp_mode, generate_grasps)
        grasps = generator(obs['object_pc'], obs['object_normals'], self.table_height, self.mu)
        if self.grasp_mode == 'wrench':
            grasps = wrench_grasps(obs['object_pc'], obs['object_normals'], self.table_height,
                                  self.mu, carry_mode=getattr(self, 'carry_mode', 'rotate'))
        self.proposals = len(grasps)
        print(f'object={self.env.object_idx} seed={self.env.seed}: {len(grasps)} proposals', flush=True)
        for index, grasp in enumerate(grasps):
            for flip in (False, True):
                if flip:
                    grasp.rotation[:, 1:] *= -1
                pre = grasp.center-grasp.rotation[:, 0]*.15
                # Allow the object's furthest point to swing below the pads.
                # Include half a finger length because contact need not be at
                # the gripper frame origin. This matters for the long banana.
                radius = np.linalg.norm(obs['object_pc']-grasp.center, axis=1).max()
                lift_height = max(.19, self.table_height+.12+radius+.0315-grasp.center[2])
                start = self.env.agent_qpos.astype(float)
                def build():
                    self.plan_failure = 'pregrasp IK'
                    target = self.planner.ik(pre, grasp.quaternion, start)
                    if target is None:
                        return None
                    self.plan_failure = 'transit'
                    transit = self.planner.plan(start, target, iterations=350)
                    if transit is None:
                        return None
                    self.plan_failure = 'approach'
                    approach = self.planner.cartesian(target, np.linspace(pre, grasp.center, 16)[1:], grasp.quaternion)
                    if approach is None:
                        return None
                    positions = grasp.center+np.linspace(0, lift_height, 24)[1:, None]*[0, 0, 1]
                    self.plan_failure = 'lift'
                    lift = self.planner.cartesian(approach[-1], positions, grasp.quaternion)
                    return (transit, approach, lift) if lift is not None else None
                plan = self.query(build)
                if plan is None:
                    self.candidate_failures.append(dict(index=index, flip=flip,
                        approach=grasp.rotation[:, 0].tolist(), center=grasp.center.tolist(),
                        stage=self.plan_failure, collision=self.planner.last_collision))
                    continue
                self.feasible_grasps += 1
                if self.feasible_grasps <= self.grasp_skip:
                    continue
                self.selected = grasp
                self.lift_height = float(lift_height)
                print(f'  selected proposal {index}, width={grasp.width:.3f}m, margin={grasp.cone_margin:.3f}', flush=True)
                self.move(plan[0], 'pregrasp', increment=.035 if self.fast_pick else .02)
                self.move(plan[1], 'approach', increment=.007)
                target = plan[1][-1].copy()
                self.phase = 'close'
                loaded = 0
                for opening in np.linspace(.05, 0., 70):
                    target[-2:] = opening
                    self.step(target)
                    row = self.trace[-1]
                    loaded = loaded+1 if min(row['finger_1_force_n'], row['finger_2_force_n']) > 45. else 0
                    if self.fast_pick and loaded >= 10:
                        break
                target[-2:] = 0.
                for _ in range(20 if self.fast_pick else 40):
                    self.step(target)
                lift = [q.copy() for q in plan[2]]
                for qlift in lift:
                    qlift[-2:] = 0.
                self.move(lift, 'lift', increment=.01 if self.fast_pick else .008)
                self.phase = 'hold'
                for _ in range(100):
                    self.step(lift[-1])
                return self.finish('executed')
        return self.finish('no feasible grasp trajectory')

    def prepare_object(self):
        """Tip a tall object onto a shorter face before the antipodal pick."""
        obs = self.env._get_obs()
        low, high = obs['object_pc'].min(axis=0), obs['object_pc'].max(axis=0)
        size = high-low
        if size[2] < 1.15*min(size[:2]):
            return
        axis = int(np.argmin(size[:2]))
        direction = np.eye(3)[axis]
        position = (low+high)/2
        position[axis] = low[axis]-.08
        position[2] = max(high[2]-.012, self.table_height+.082)
        quaternion = Rotation.from_euler('z', axis*np.pi/2).as_quat()
        start = self.env.agent_qpos.astype(float)
        def build():
            target = self.planner.ik(position, quaternion, start, attempts=15)
            if target is None:
                return None
            target[-2:] = 0.
            return self.planner.plan(start, target)
        path = self.query(build)
        if path is None:
            self.preparation = 'no clear tipping approach'
            return
        self.move(path, 'tip approach', increment=.08)
        self.planner.touch_palm = True
        try:
            self.phase = 'tip object'
            q = self.env.agent_qpos.astype(float)
            for advance in np.linspace(.002, .14, 70):
                target = position+advance*direction
                def next_target():
                    next_q = self.planner.ik(target, quaternion, q, attempts=1)
                    return next_q if next_q is not None and self.planner.edge(q, next_q, True) else None
                next_q = self.query(next_target)
                if next_q is None:
                    break
                next_q[-2:] = 0.
                self.step(next_q)
                q = next_q
                cloud = self.env._get_obs()['object_pc']
                if np.ptp(cloud[:, 2]) < .85*size[2]:
                    break
            ee = p.getLinkState(self.env.robot_id, self.planner.ee, computeForwardKinematics=True)
            positions = np.array(ee[4])-np.linspace(0, .10, 12)[1:, None]*direction
            path = self.query(lambda: self.planner.cartesian(self.env.agent_qpos.astype(float), positions, quaternion))
            if path is not None:
                self.move(path, 'tip retreat', increment=.02)
            self.phase = 'tip settle'
            q = self.env.agent_qpos.astype(float)
            q[-2:] = .05
            for _ in range(20):
                self.step(q)
            self.preparation = 'tipped and settled on table'
        finally:
            self.planner.touch_palm = False

    def finish(self, reason):
        hold = [r for r in self.trace if r['phase'] == 'hold']
        longest, consecutive = 0, 0
        for row in hold:
            stable = row['clearance'] >= .1 and row['bilateral_contact'] and row['relative_drift'] < .02
            consecutive = consecutive+1 if stable else 0
            longest = max(longest, consecutive)
        lifted = [r for r in self.trace if r['clearance'] >= .1 and r['bilateral_contact']]
        first_lift = lifted[0]['physics_steps'] if lifted else None
        result = dict(object_idx=self.env.object_idx, seed=self.env.seed, reason=reason,
            proposals=getattr(self, 'proposals', 0), selected=self.selected is not None,
            grasp_mode=self.grasp_mode, grasp_skip=self.grasp_skip,
            fast_pick=self.fast_pick,
            preparation=self.preparation,
            feasible_grasps=self.feasible_grasps,
            success=bool(longest >= 50 and first_lift is not None and first_lift <= 3000
                         and self.trace[-1]['clearance'] >= .1),
            first_lift_physics_steps=first_lift,
            max_clearance_m=max((r['clearance'] for r in self.trace if r['phase'] in ('lift', 'hold')), default=0.), final_clearance_m=self.trace[-1]['clearance'],
            stable_hold_control_steps=longest, stable_hold_physics_steps=longest*self.env.substeps,
            control_steps=self.env.step_count, physics_steps=self.env.step_count*self.env.substeps,
            collision_checks=self.planner.checks, wall_seconds=time.perf_counter()-self.start_time,
            max_hold_relative_drift_m=max((r['relative_drift'] for r in hold), default=None),
            mu_filter=self.mu, position_error_m=None, orientation_error_rad=None)
        result['max_robot_obstacle_penetration_m'] = max(r['obstacle_penetration_m'] for r in self.trace)
        result['sustained_hold'] = bool(longest == 100 and self.trace[-1]['clearance'] >= .1)
        result['planned_lift_m'] = getattr(self, 'lift_height', None)
        if self.selected is not None:
            ee = p.getLinkState(self.env.robot_id, self.planner.ee, computeForwardKinematics=True)
            result['position_error_m'] = float(np.linalg.norm(np.array(ee[4])-(self.selected.center+[0, 0, self.lift_height])))
            result['orientation_error_rad'] = float((Rotation.from_quat(self.selected.quaternion)*Rotation.from_quat(ee[5]).inv()).magnitude())
            result['grasp'] = dict(contacts=self.selected.contacts.tolist(), center=self.selected.center.tolist(),
                quaternion=self.selected.quaternion.tolist(), width=self.selected.width, cone_margin=self.selected.cone_margin)
            result['grasp']['transport_capacity_kg'] = self.selected.transport_capacity_kg
        (self.output/'result.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
        (self.output/'candidate_failures.json').write_text(json.dumps(self.candidate_failures, indent=2), encoding='utf-8')
        with (self.output/'trace.csv').open('w', newline='') as stream:
            writer = csv.DictWriter(stream, fieldnames=self.trace[0].keys())
            writer.writeheader()
            writer.writerows(self.trace)
        if self.record:
            self.capture().save(self.output/'final.png')
            if self.frames:
                self.frames[0].save(self.output/'demo.gif', save_all=True, append_images=self.frames[1:], duration=165, loop=0)
        print(json.dumps({k:v for k,v in result.items() if k != 'grasp'}, indent=2), flush=True)
        return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--headless', action='store_true')
    parser.add_argument('--record', action='store_true')
    parser.add_argument('--objects', nargs='+', type=int, default=[5])
    parser.add_argument('--seeds', nargs='+', type=int, default=[42])
    parser.add_argument('--output', type=Path, default=Path('results/grasping'))
    parser.add_argument('--mu', type=float, default=.5)
    parser.add_argument('--fast-pick', action='store_true')
    args = parser.parse_args()
    results = []
    for obj in args.objects:
        for seed in args.seeds:
            env = PickNavReachEnv(seed=seed, object_idx=obj, gui=not args.headless)
            try:
                results.append(GraspExperiment(env, args.output/f'object_{obj:02d}_seed_{seed}', args.record, args.mu,
                                                fast_pick=args.fast_pick).run())
            finally:
                env.close()
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output/'summary.json').write_text(json.dumps(results, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
