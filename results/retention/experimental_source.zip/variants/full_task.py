"""Pick, carry through the maze, and reach: python full_task.py --headless."""
import argparse
import csv
import json
import time
from pathlib import Path
import numpy as np
import pybullet as p
from scipy.spatial.transform import Rotation, Slerp

from controller import GraspExperiment
from navigation import GridNavigator, scurve_profile
from pick_nav_reach_env import PickNavReachEnv
from retention import GripRegulator, BalancedGrip


class TaskFailure(RuntimeError):
    pass


class FullTaskExperiment(GraspExperiment):
    def __init__(self, *args, carry_mode='rotate', speed=.9, acceleration=.8,
                 tuck_increment=.012, grip_mode='closed', grip_force=20.,
                 tuck_profile='linear', tuck_path='joint', slip_servo=False,
                 table_regrasp=False, jerk=0., **kwargs):
        super().__init__(*args, **kwargs)
        self.carry_mode = carry_mode
        self.speed, self.acceleration = speed, acceleration
        self.tuck_increment = tuck_increment
        self.grip_mode, self.grip_force = grip_mode, grip_force
        self.grip = None
        self.tuck_profile = tuck_profile
        self.tuck_path = tuck_path
        self.slip_servo = slip_servo
        self.servo_reference = None
        self.servo_offset = np.zeros(self.env.action_size)
        self.table_regrasp = table_regrasp
        self.regrasp_result = None
        self.jerk = jerk
        self.transport_started = False
        self.carry_reference = None
        self.max_carry_drift = 0.
        self.task_trace = []
        self.route = []

    def run(self):
        try:
            return super().run()
        except TaskFailure as error:
            return self.finish(str(error))

    def step(self, q):
        if self.transport_started:
            q = np.array(q, dtype=float, copy=True)
            if self.grip_mode == 'balanced':
                positions = self.env.agent_qpos[-2:]
                if self.grip is None:
                    self.grip = BalancedGrip(positions)
                row = self.trace[-1]
                q[-2:] = self.grip.targets(positions, [row['finger_1_force_n'], row['finger_2_force_n']])
            elif self.grip_mode == 'regulated':
                if self.grip is None:
                    self.grip = GripRegulator(self.env.agent_qpos[-2:], self.grip_force)
                row = self.trace[-1]
                q[-2:] = self.grip.targets([row['finger_1_force_n'], row['finger_2_force_n']])
            else:
                q[-2:] = 0.
            if self.slip_servo and self.servo_reference is not None:
                measured = self.env.agent_qpos.astype(float)
                ee = p.getLinkState(self.env.robot_id, self.planner.ee, computeForwardKinematics=True)
                obj = p.getBasePositionAndOrientation(self.env.object_id)
                desired = p.multiplyTransforms(*obj, *p.invertTransform(*self.servo_reference))
                error = np.r_[np.array(desired[0])-ee[4],
                    (Rotation.from_quat(desired[1])*Rotation.from_quat(ee[5]).inv()).as_rotvec()]
                linear, angular = p.calculateJacobian(self.env.robot_id, self.planner.ee, [0, 0, 0],
                    measured.tolist(), [0.]*len(measured), [0.]*len(measured))
                jac = np.vstack((linear, angular))[:, self.planner.active]
                delta = jac.T@np.linalg.solve(jac@jac.T+.003*np.eye(6), .25*error)
                self.servo_offset[self.planner.active] += np.clip(delta, -.004, .004)
                self.servo_offset = np.clip(self.servo_offset, -.2, .2)
                q += self.servo_offset
                if not self.query(lambda: self.planner.clear(q)):
                    raise TaskFailure('slip correction blocked by collision geometry')
            self.camera_focus = np.r_[self.env.agent_qpos[:2]+[-2, 0], .85].tolist()
        if self.env.step_count*self.env.substeps >= 15000:
            raise TaskFailure('15000 physics-step budget exhausted')
        obs = super().step(q)
        distance = float(np.linalg.norm(obs['object_pos']-obs['goal_pos']))
        if self.transport_started:
            ee = p.getLinkState(self.env.robot_id, self.planner.ee, computeForwardKinematics=True)
            relative = np.array(p.multiplyTransforms(*p.invertTransform(ee[4], ee[5]),
                                                     obs['object_pos'], obs['object_xyzw'])[0])
            drift = float(np.linalg.norm(relative-self.carry_reference))
            self.max_carry_drift = max(self.max_carry_drift, drift)
            if obs['object_pos'][2] < .45 or drift > .09:
                raise TaskFailure('object slipped from the gripper')
        self.task_trace.append(dict(physics_steps=self.env.step_count*self.env.substeps,
                                   phase=self.phase, distance_to_goal_m=distance,
                                   carry_drift_m=self.max_carry_drift))
        return obs

    def update_payload(self):
        ee = p.getLinkState(self.env.robot_id, self.planner.ee, computeForwardKinematics=True)
        obs = self.env._get_obs()
        self.planner.payload = p.multiplyTransforms(*p.invertTransform(ee[4], ee[5]),
                                                    obs['object_pos'], obs['object_xyzw'])

    def footprint(self):
        """Conservative union of all robot collision AABBs and the object."""
        boxes = [p.getAABB(self.env.robot_id, link) for link in range(-1, p.getNumJoints(self.env.robot_id))
                 if p.getCollisionShapeData(self.env.robot_id, link)]
        boxes.append(p.getAABB(self.env.object_id))
        origin = self.env.agent_qpos[:2]+[-2, 0]
        return np.min(np.array(boxes)[:, 0, :2], axis=0)-origin, np.max(np.array(boxes)[:, 1, :2], axis=0)-origin

    def drive(self, path, speed=.9, acceleration=.8, phase='navigate'):
        """Stop at corners using bounded-acceleration base targets."""
        self.phase = phase
        self.servo_offset[:] = 0.
        if self.slip_servo:
            self.update_payload()
            self.servo_reference = self.planner.payload
        dt = self.env.substeps/240.
        for target in path[1:]:
            start = self.env.agent_qpos.astype(float)
            delta = target[:2]-start[:2]
            length = np.linalg.norm(delta)
            if length < 1e-6:
                continue
            if self.jerk > 0:
                _, profile = scurve_profile(length, speed, acceleration, self.jerk, dt)
                for distance in profile[1:, 0]:
                    q = target.copy()
                    q[:2] = start[:2]+delta*distance/length
                    self.step(q)
                for _ in range(8):
                    self.step(target)
                continue
            peak = min(speed, np.sqrt(length*acceleration))
            ramp = peak/acceleration
            cruise = max(0., (length-peak*ramp)/peak)
            duration = 2*ramp+cruise
            for t in np.arange(dt, duration+dt, dt):
                t = min(t, duration)
                if t < ramp:
                    distance = .5*acceleration*t*t
                elif t < ramp+cruise:
                    distance = .5*peak*ramp+peak*(t-ramp)
                else:
                    distance = length-.5*acceleration*(duration-t)**2
                q = target.copy()
                q[:2] = start[:2]+delta*distance/length
                self.step(q)
            for _ in range(8):
                self.step(target)
        self.servo_reference = None

    def carry_and_reach(self):
        if self.table_regrasp:
            self.reorient_on_table()
        self.transport_started = True
        self.update_payload()
        self.carry_reference = np.array(self.planner.payload[0])
        # Retract above the tabletop, with the heading fixed throughout transport.
        start = self.env.agent_qpos.astype(float)
        ee = p.getLinkState(self.env.robot_id, self.planner.ee, computeForwardKinematics=True)
        base = start[:2]+[-2, 0]
        # Alternate orientations are exposed for reproducible carry experiments.
        support = self.carry_mode == 'support'
        carry_rotation = Rotation.from_quat(ee[5])
        if self.carry_mode == 'axial':
            carry_rotation = carry_rotation*Rotation.from_euler('y', np.pi/2)
            if carry_rotation.as_matrix()[0, 0] < 0:
                carry_rotation = Rotation.from_quat(ee[5])*Rotation.from_euler('y', -np.pi/2)
        elif self.carry_mode in ('cradle', 'palm'):
            carry_rotation = carry_rotation*Rotation.from_euler('y', np.pi)
        elif self.carry_mode == 'vertical':
            carry_rotation = Rotation.from_euler('y', np.pi/2)
        elif support:
            carry_rotation = carry_rotation*Rotation.from_euler('z', -np.pi/2)
        elif self.carry_mode == 'rotate':
            carry_rotation = Rotation.from_euler('y', -np.pi/2)*carry_rotation
        carry_quat = carry_rotation.as_quat()
        direction = carry_rotation.as_matrix()[:2, 0] if support or self.carry_mode == 'axial' else np.array([1., 0])
        direction = direction/np.linalg.norm(direction)
        carry = None
        rotated = self.carry_mode != 'topdown'
        for x in ((.45, .5, .42, .55) if self.carry_mode in ('cradle', 'palm') else
                  ((.55, .5, .45, .42) if self.tuck_path == 'cartesian' else
                  ((.5, .45, .42, .55) if rotated else (.45, .42, .5, .55)))):
            for z in ((ee[4][2], .9, 1.05, 1.15) if self.tuck_path == 'cartesian' else
                      ((.9, 1.05, 1.15, 1.25) if rotated else (1.05, .9, 1.15, 1.25))):
                def build():
                    if self.tuck_path == 'cartesian':
                        t = np.linspace(0, 1, 70)[1:]
                        t = t**3*(10-15*t+6*t*t)
                        positions = np.array(ee[4])+t[:, None]*(np.r_[base+direction*x, z]-ee[4])
                        rotations = Slerp([0, 1], Rotation.from_quat([ee[5], carry_quat]))(t)
                        quats = rotations.as_quat()
                        if self.carry_mode in ('cradle', 'palm'):
                            relative = np.array(self.planner.payload[0])
                            obj_start = np.array(ee[4])+Rotation.from_quat(ee[5]).apply(relative)
                            obj_end = np.r_[base+direction*x, z]+carry_rotation.apply(relative)
                            positions = obj_start+t[:, None]*(obj_end-obj_start)-rotations.apply(relative)
                        return self.planner.cartesian(start, positions, quats)
                    target = self.planner.ik(np.r_[base+direction*x, z], carry_quat, start,
                                             attempts=30, collision_free=True)
                    if target is None:
                        return None
                    target[-2:] = 0
                    return self.planner.plan(start, target)
                carry = self.query(build)
                if carry is not None:
                    break
            if carry is not None:
                break
        if carry is None:
            raise TaskFailure('no collision-free carrying posture')
        self.move(carry, 'tuck', increment=self.tuck_increment, smooth=self.tuck_profile == 'smooth')
        if self.carry_mode == 'palm':
            self.grip_mode, self.grip_force = 'regulated', 10.
            self.grip = None
            self.phase = 'palm seat'
            q = self.env.agent_qpos.astype(float)
            for _ in range(40):
                self.step(q)
        self.update_payload()
        # Back away before applying the conservative tabletop footprint.
        start = self.env.agent_qpos.astype(float)
        retreat = start.copy()
        retreat[0] = min(start[0], .6)
        if not self.query(lambda: self.planner.edge(start, retreat)):
            raise TaskFailure(f'retreat blocked: {self.planner.last_collision}')
        self.drive([start, retreat], speed=min(.4, self.speed),
                   acceleration=min(.3, self.acceleration), phase='retreat')
        # Retreat can shift the object inside the grasp. Validate the maze
        # route using the observed pose, rather than the pre-retreat pose.
        self.update_payload()
        obs = self.env._get_obs()
        base = obs['qpos'][:2]+[-2, 0]
        offset = obs['object_pos'][:2]-base
        # Stage just inside the exit; the object itself must reach the marker.
        goal_base = obs['goal_pos'][:2]-offset
        table_box = p.getAABB(self.env.table_id)
        nav = GridNavigator(obs['cube_positions'], self.footprint(),
                            extra_boxes=[(np.array(table_box[0])[:2], np.array(table_box[1])[:2])])
        print('Carrying footprint:', self.footprint(), flush=True)
        route = nav.plan(base, goal_base)
        if route is None:
            # A centered object can require an off-center base in an asymmetric
            # posture. Stage nearby and let the checked arm reach do the rest.
            offsets = [np.array([x, y]) for x in np.arange(-.4, .41, .1)
                       for y in np.arange(-.4, .41, .1)]
            offsets.sort(key=np.linalg.norm)
            for delta in offsets:
                staging = goal_base+delta
                if not nav.clear_edge(staging, staging):
                    continue
                def can_reach():
                    q = self.env.agent_qpos.astype(float)
                    q[:2] = staging-[-2, 0]
                    pos, rot = self.planner.pose(q)
                    object_pos = pos+rot.apply(self.planner.payload[0])
                    positions = pos+np.linspace(0, 1, 24)[1:, None]*(obs['goal_pos']-object_pos)
                    return self.planner.cartesian(q, positions, rot.as_quat()) is not None
                if not self.query(can_reach):
                    continue
                route = nav.plan(base, staging)
                if route is not None:
                    break
        if route is None:
            raise TaskFailure('no route for the carrying footprint')
        self.route = [point.tolist() for point in route]
        print(f'Navigation: {len(route)} waypoints, {nav.expanded} A* expansions', flush=True)
        q = self.env.agent_qpos.astype(float)
        path = [q.copy()]
        for point in route[1:]:
            target = q.copy()
            target[:2] = point-[-2, 0]
            path.append(target)
        # Check actual link and carried-object geometry before motor execution.
        if not self.query(lambda: all(self.planner.edge(a, b) for a, b in zip(path, path[1:]))):
            raise TaskFailure('route failed full-geometry collision validation')
        self.drive(path, speed=self.speed, acceleration=self.acceleration)
        # Recompute object-to-gripper offset after transport to correct any slip.
        for _ in range(3):
            self.update_payload()
            start = self.env.agent_qpos.astype(float)
            ee = p.getLinkState(self.env.robot_id, self.planner.ee, computeForwardKinematics=True)
            obs = self.env._get_obs()
            correction = obs['goal_pos']-obs['object_pos']
            if np.linalg.norm(correction) < .075:
                break
            positions = np.array(ee[4])+np.linspace(0, 1, 20)[1:, None]*correction
            path = self.query(lambda: self.planner.cartesian(start, positions, ee[5]))
            if path is None:
                raise TaskFailure('final object-position correction blocked')
            self.move(path, 'reach', increment=.006)
        self.phase = 'goal hold'
        q = self.env.agent_qpos.astype(float)
        for _ in range(60):
            self.step(q)
        if not all(row['distance_to_goal_m'] < .1 for row in self.task_trace[-60:]):
            raise TaskFailure('final object position outside 10 cm tolerance')

    def reorient_on_table(self):
        """Use the table as a fixture, then pinch the shorter vertical section."""
        self.update_payload()
        relative = np.array(self.planner.payload[0])
        obs = self.env._get_obs()
        ee = p.getLinkState(self.env.robot_id, self.planner.ee, computeForwardKinematics=True)
        first = Rotation.from_quat(ee[5])
        last = first*Rotation.from_euler('y', np.pi/2)
        if last.as_matrix()[0, 0] < 0:
            last = first*Rotation.from_euler('y', -np.pi/2)
        t = np.linspace(0, 1, 90)[1:]
        t = t**3*(10-15*t+6*t*t)
        rotations = Slerp([0, 1], Rotation.from_quat([ee[5], last.as_quat()]))(t)
        positions = obs['object_pos']-rotations.apply(relative)
        start = self.env.agent_qpos.astype(float)
        path = self.query(lambda: self.planner.cartesian(start, positions, rotations.as_quat()))
        if path is None:
            raise TaskFailure('table reorientation path blocked')
        for q in path:
            q[-2:] = 0.
        self.move(path, 'table reorient', increment=.01)
        self.update_payload()
        obs = self.env._get_obs()
        # Estimate the rotated support height from the measured point cloud.
        bottom_offset = obs['object_pc'][:, 2].min()-obs['object_pos'][2]
        radius_x = max(abs(obs['object_pc'][:, 0]-obs['object_pos'][0]))
        table_low = np.array(p.getAABB(self.env.table_id)[0])
        obj_target = np.array([table_low[0]+radius_x+.035, 0.,
                               self.table_height-bottom_offset+.015])
        ee = p.getLinkState(self.env.robot_id, self.planner.ee, computeForwardKinematics=True)
        rot = Rotation.from_quat(ee[5])
        target = obj_target-rot.apply(self.planner.payload[0])
        above = target.copy()
        above[2] = ee[4][2]
        positions = np.vstack((np.linspace(ee[4], above, 35)[1:],
                                np.linspace(above, target, 40)[1:]))
        start = self.env.agent_qpos.astype(float)
        path = self.query(lambda: self.planner.cartesian(start, positions, ee[5]))
        if path is None:
            raise TaskFailure('table placement path blocked')
        for q in path:
            q[-2:] = 0.
        self.move(path, 'table place', increment=.01)
        self.planner.payload = None
        self.phase = 'release on table'
        q = self.env.agent_qpos.astype(float)
        for opening in np.linspace(q[-2:].mean(), .05, 30):
            q[-2:] = opening
            self.step(q)
        for _ in range(20):
            self.step(q)
        ee = p.getLinkState(self.env.robot_id, self.planner.ee, computeForwardKinematics=True)
        direction = Rotation.from_quat(ee[5]).as_matrix()[:, 0]
        positions = np.array(ee[4])-np.linspace(0, .15, 30)[1:, None]*direction
        path = self.query(lambda: self.planner.cartesian(self.env.agent_qpos.astype(float), positions, ee[5]))
        if path is None:
            raise TaskFailure('table regrasp retreat blocked')
        self.move(path, 'regrasp retreat', increment=.015)
        second = GraspExperiment(self.env, self.output/'regrasp', self.record, self.mu, fast_pick=True)
        result = second.run()
        self.trace.extend(second.trace)
        self.frames.extend(second.frames)
        self.regrasp_result = result
        if result['stable_hold_control_steps'] < 50 or result['final_clearance_m'] < .1:
            raise TaskFailure('regrasp did not hold the reoriented object')

    def finish(self, reason):
        pick = super().finish(reason)
        task_reason = reason if reason != 'executed' else 'grasp did not remain stable'
        reached = False
        acquired = pick['stable_hold_control_steps'] >= 50 and pick['final_clearance_m'] >= .1
        if acquired and self.env.step_count*self.env.substeps < 15000:
            try:
                self.carry_and_reach()
                reached, task_reason = True, 'delivered and held at goal'
            except TaskFailure as error:
                task_reason = str(error)
        result = dict(object_idx=self.env.object_idx, seed=self.env.seed, success=reached,
                      reason=task_reason, pick_success=pick['success'],
                      distance_to_goal_m=float(self.env.evaluate()['dist_to_goal']),
                      physics_steps=self.env.step_count*self.env.substeps,
                      max_carry_drift_m=self.max_carry_drift,
                      carry_stable=bool(reached and self.max_carry_drift < .09),
                      max_robot_obstacle_penetration_m=max(r['obstacle_penetration_m'] for r in self.trace),
                      wall_seconds=time.perf_counter()-self.start_time,
                      collision_checks=self.planner.checks,
                      cube_positions=self.env.cube_positions[:, :2].tolist(),
                      goal_pos=self.env.goal_pos.tolist(),
                      carry_mode=self.carry_mode,
                      speed_m_s=self.speed, acceleration_m_s2=self.acceleration,
                      tuck_increment=self.tuck_increment,
                      grip_mode=self.grip_mode, grip_force_n=self.grip_force,
                      tuck_profile=self.tuck_profile,
                      tuck_path=self.tuck_path,
                      slip_servo=self.slip_servo,
                      table_regrasp=self.table_regrasp, regrasp=self.regrasp_result,
                      jerk_m_s3=self.jerk,
                      solver_iterations=p.getPhysicsEngineParameters()['numSolverIterations'],
                      route=self.route, pick=pick)
        (self.output/'task_result.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
        for name, rows in [('trace.csv', self.trace), ('task_trace.csv', self.task_trace)]:
            if rows:
                with (self.output/name).open('w', newline='') as stream:
                    writer = csv.DictWriter(stream, fieldnames=rows[0].keys())
                    writer.writeheader()
                    writer.writerows(rows)
        if self.record:
            self.capture().save(self.output/'final.png')
            if self.frames:
                self.frames[0].save(self.output/'demo.gif', save_all=True, append_images=self.frames[1:], duration=165, loop=0)
        print(json.dumps({k: v for k, v in result.items() if k not in ('pick', 'route', 'cube_positions')}, indent=2), flush=True)
        return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--headless', action='store_true')
    parser.add_argument('--record', action='store_true')
    parser.add_argument('--carry-mode', choices=['rotate', 'topdown', 'support', 'vertical', 'cradle', 'palm', 'axial'], default='rotate')
    parser.add_argument('--speed', type=float, default=.9)
    parser.add_argument('--acceleration', type=float, default=.8)
    parser.add_argument('--tuck-increment', type=float, default=.012)
    parser.add_argument('--grasp-mode', choices=['topdown', 'transport', 'aligned', 'surface', 'wrench', 'narrow', 'facet'], default='topdown')
    parser.add_argument('--mu', type=float, default=.5)
    parser.add_argument('--grasp-skip', type=int, default=0)
    parser.add_argument('--fast-pick', action='store_true')
    parser.add_argument('--grip-mode', choices=['closed', 'regulated', 'balanced'], default='closed')
    parser.add_argument('--grip-force', type=float, default=20.)
    parser.add_argument('--tuck-profile', choices=['linear', 'smooth'], default='linear')
    parser.add_argument('--tuck-path', choices=['joint', 'cartesian'], default='joint')
    parser.add_argument('--slip-servo', action='store_true')
    parser.add_argument('--table-regrasp', action='store_true')
    parser.add_argument('--jerk', type=float, default=0.)
    parser.add_argument('--tip-tall', action='store_true')
    parser.add_argument('--solver-iterations', type=int)
    parser.add_argument('--objects', nargs='+', type=int, default=[5])
    parser.add_argument('--seeds', nargs='+', type=int, default=[7])
    parser.add_argument('--output', type=Path, default=Path('results/full_task'))
    args = parser.parse_args()
    results = []
    for obj in args.objects:
        for seed in args.seeds:
            env = PickNavReachEnv(seed=seed, object_idx=obj, gui=not args.headless,
                                  solver_iterations=args.solver_iterations)
            try:
                experiment = FullTaskExperiment(env, args.output/f'object_{obj:02d}_seed_{seed}', args.record,
                                                  carry_mode=args.carry_mode, speed=args.speed,
                                                  acceleration=args.acceleration,
                                                  tuck_increment=args.tuck_increment,
                                                  grip_mode=args.grip_mode, grip_force=args.grip_force,
                                                  tuck_profile=args.tuck_profile,
                                                  tuck_path=args.tuck_path,
                                                  slip_servo=args.slip_servo,
                                                  table_regrasp=args.table_regrasp,
                                                  jerk=args.jerk,
                                                  grasp_mode=args.grasp_mode, grasp_skip=args.grasp_skip,
                                                  fast_pick=args.fast_pick,
                                                  mu=args.mu)
                experiment.tip_tall = args.tip_tall
                results.append(experiment.run())
            finally:
                env.close()
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output/'summary.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
    with (args.output/'summary.csv').open('w', newline='') as stream:
        fields = ['object_idx', 'seed', 'success', 'reason', 'pick_success', 'distance_to_goal_m',
                  'physics_steps', 'max_carry_drift_m', 'carry_stable']
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(results)


if __name__ == '__main__':
    main()
